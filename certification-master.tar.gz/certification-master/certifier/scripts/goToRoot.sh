#!/bin/bash

# $1, the dnnf
# $2, the starting node

node=$2

while [ $node -ne 1 ]
do
    save=$(grep " $node " $1 | grep -v "o" | grep -v "a" | grep " $node 2 ")
    node=$(echo $save | cut -d ' ' -f1)
    echo $save
done
