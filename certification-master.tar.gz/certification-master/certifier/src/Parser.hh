#ifndef Certif_Dimacs_h
#define Certif_Dimacs_h

#include <iostream>
#include <limits>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <fstream>

#include "SolverTypes.hh"
#include "Dag.hh"

namespace Certifier
{
#define BUFFER_SIZE 65536
class BufferRead
{
  int pos;
  int size;
  char buffer[BUFFER_SIZE];
  FILE *f;

 public:
  BufferRead(std::string &name)
  {
    pos = 0;
    size = 0;

    f = fopen(name.c_str(), "r");
    if(!f) std::cerr << "ERROR! Could not open file: " <<  name << "\n", exit(1);

    // fill the buffer
    size = fread(buffer, sizeof(char), BUFFER_SIZE, f);
    if (!size && ferror(f)) std::cerr << "Cannot read the file: " <<  name << "\n", exit(1);
  }

  ~BufferRead()
  {
    if(f) fclose(f);
  }

  inline char currentChar(){return buffer[pos];}
  inline char nextChar()
  {
    char c = buffer[pos];
    consumeChar();
    return c;
  }

  inline void consumeChar()
  {
    pos++;
    if(pos >= size)
    {
      pos = 0;
      size = fread(buffer, sizeof(char), BUFFER_SIZE, f);
      if(!size && ferror(f)) std::cerr << "Cannot read the reamaining\n", exit(1);
    }
  }

  inline bool eof(){return !size && feof(f);}
  inline void skipSpace()
  {
    while(!eof() && (currentChar() == ' ' || currentChar() == '\t'
                     || currentChar() == '\n' || currentChar() == '\r')) consumeChar();
  }

  inline void skipLine()
  {
    while(!eof() && currentChar() != '\n') consumeChar();
    consumeChar();
  }

  inline int nextInt()
  {
    int ret = 0;
    skipSpace();

    bool sign = currentChar() == '-';
    if(sign) consumeChar();
    while(!eof() && currentChar() >= '0' && currentChar() <= '9')
    {
      ret = ret * 10 + (nextChar() - '0');
    }
    return (sign) ? -ret : ret;
  }
};



Lit stringToLit(std::string s)
{
  int v = stoi(s);
  int av = abs(v);
  return (v > 0) ?  mkLit(av) : ~mkLit(av);
}

Lit intToLit(int v)
{
  int av = abs(v);
  return (v > 0) ?  mkLit(av) : ~mkLit(av);
}



static int parse_DIMACS_main(BufferRead &in, std::vector< std::vector<Lit> > &clauses)
{
  std::vector<Lit> lits;
  std::string s;

  int nbVars = 0;
  int nbClauses = 0;

  for (;;)
  {
    in.skipSpace();
    if (in.eof()) break;

    if (in.currentChar() == 'p')
    {
      in.consumeChar();
      in.skipSpace();
      if(in.nextChar() != 'c' || in.nextChar() != 'n' || in.nextChar() != 'f')
        std::cerr << "PARSE ERROR! Unexpected char: " << in.currentChar() << "\n", exit(3);

      nbVars = in.nextInt();
      nbClauses = in.nextInt();
      if (nbClauses < 0) printf("parse error\n"), exit(2);
    }
    else if (in.currentChar() == 'c') in.skipLine();
    else
    {
      lits.clear();
      int v = -1;
      do
      {
        v = in.nextInt();
        if(v) lits.push_back(intToLit(v));
      } while(v);

      assert(lits.size());
      clauses.push_back(lits);
    }
  }

  return nbVars;
}

  /**
     Get the clauses from the drat file (we do not consider deleted clauses).
   */
static void parse_DRAT_main(BufferRead &in, std::vector< std::vector<Lit> > &clauses)
{
  std::vector<Lit> lits;

  for (;;)
  {
    in.skipSpace();
    if (in.eof()) break;
    else if (in.currentChar() == 'c' || in.currentChar() == 'd') in.skipLine();
    else
    {
      lits.clear();
      int v = -1;
      do
      {
        v = in.nextInt();
        if(v) lits.push_back(intToLit(v));
      } while(v);
      clauses.push_back(lits);
    }
  }
}// parse_DRAT_main

struct Couple
{
  int x, y;
};

/**
   Parse the Ddnnf from the input file
*/
static Dag *parse_DDnnf_main(BufferRead &in)
{
  std::vector<Dag *> listOfNodes;
  std::vector<int> values;

  listOfNodes.push_back(NULL); // because we start with the index 1
  std::vector<int> emptyIdx;
  // listOfNodes.push_back(new OrNode(emptyIdx));

  for (;;)
  {
    in.skipSpace();
    values.clear();

    if (in.eof()) break;
    else if (in.currentChar() == 'o' || in.currentChar() == 'O')
    {
      in.consumeChar();
      int v = -1;
      while(v)
      {
        assert(!in.eof());
        v = in.nextInt();
        if(v) values.push_back(v);
      }

      // we first get the index of the node.
      int idx = values[0];
      while((int) listOfNodes.size() <= idx) listOfNodes.push_back(NULL);
      assert(listOfNodes[idx] == NULL);

      // the remaing values
      std::vector<int> idxReason;
      for(unsigned i = 2 ; i<values.size() ; i++)
      {
        idxReason.push_back(values[i] - 1);
      }

      listOfNodes[idx] = new OrNode(idxReason);
    }
    else if (in.currentChar() == 'a' || in.currentChar() == 'A')
    {
      in.consumeChar();
      int v = -1;
      while(v)
      {
        assert(!in.eof());
        v = in.nextInt();
        if(v) values.push_back(v);
      }

      int idx = values[0];
      while((int) listOfNodes.size() <= idx) listOfNodes.push_back(NULL);
      assert(listOfNodes[idx] == NULL);

      // the remaing values
      std::vector<int> idxReason;
      for(unsigned i = 2 ; i<values.size() ; i++)
      {
        idxReason.push_back(values[i] - 1);
      }

      listOfNodes[idx] = new AndNode(idxReason);
    } else if (in.currentChar() == 't' || in.currentChar() == 'T')
    {
      in.consumeChar();
      int v = -1;
      while(v)
      {
        assert(!in.eof());
        v = in.nextInt();
        if(v) values.push_back(v);
      }

      int idx = values[0];

      while((int) listOfNodes.size() <= idx) listOfNodes.push_back(NULL);
      assert(listOfNodes[idx] == NULL);
      listOfNodes[idx] = new True();
    }
    else if (in.currentChar() == 'f' || in.currentChar() == 'F')
    {
      in.consumeChar();
      int v = -1;
      while(v)
      {
        assert(!in.eof());
        v = in.nextInt();
        if(v) values.push_back(v);
      }

      int idx = values[0];
      while((int) listOfNodes.size() <= idx) listOfNodes.push_back(NULL);
      assert(listOfNodes[idx] == NULL);
      listOfNodes[idx] = new False();
    }
    else
    {
      int v = -1;
      do
      {
        assert(!in.eof());
        v = in.nextInt();
        if(v) values.push_back(v);
      } while(v);
      assert(!v);

      int start = values[0];
      int end = values[1];
      assert(listOfNodes[start] && listOfNodes[end]);
      assert(listOfNodes[start]->type == TYPE_OR || listOfNodes[start]->type == TYPE_AND);

      bool fcache = values[2] & 1; // 1 means true, 2 means false => &1 works

      if(listOfNodes[start]->type == TYPE_OR)
      {
        std::vector<Lit> units;
        for(unsigned i = 3 ; i<values.size() ; i++)
        {
          bool sign = (values[i] < 0);
          Var absLit = (sign) ? -values[i] : values[i];
          units.push_back(mkLit(absLit, sign));
        }

        static_cast<OrNode*>(listOfNodes[start])->addBranch(listOfNodes[end], units, fcache);
      }

      if(listOfNodes[start]->type == TYPE_AND)
        static_cast<AndNode*>(listOfNodes[start])->addBranch(listOfNodes[end], fcache);
    }
  }

  Dag *ret = listOfNodes[1];
  return ret;
}// parse_DRAT_main


static int parse_DIMACS(std::string input_stream, std::vector< std::vector<Lit> > &clauses)
{
  BufferRead in(input_stream);
  return parse_DIMACS_main(in, clauses);
}// parse_DIMACS

static void parse_DRAT(std::string input_stream, std::vector< std::vector<Lit> > &clauses)
{
  BufferRead in(input_stream);
  parse_DRAT_main(in, clauses);
}// parse_DRAT

static Dag *parse_DDnnf(std::string input_stream)
{
  BufferRead in(input_stream);
  return parse_DDnnf_main(in);
}// parse_DDnnf


  //=================================================================================================
}

#endif
