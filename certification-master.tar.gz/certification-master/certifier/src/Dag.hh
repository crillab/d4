#ifndef CERTIFICATOR_DAG_H
#define CERTIFICATOR_DAG_H

#include <vector>
#include <algorithm>

#include "SolverTypes.hh"

#define TYPE_UNDEF 0
#define TYPE_AND 1
#define TYPE_OR 2
#define TYPE_FALSE 3
#define TYPE_TRUE 4

#include <boost/multiprecision/gmp.hpp>
using namespace boost::multiprecision;


namespace Certifier
{
struct sort_lt
{
  std::vector< std::vector<int> > &clauses;
  sort_lt(std::vector< std::vector<int> > &clauses_) : clauses(clauses_) {}

  bool operator () (int x, int y)
  {
    if(clauses[x].size() == clauses[y].size())
    {
      for(unsigned i = 0 ; i<clauses[x].size() ; i++)
        if(clauses[x][i] != clauses[y][i]) return clauses[x][i] < clauses[y][i];
      return x < y; // equal
    }

    return clauses[x].size() < clauses[y].size();
  }
};


class Problem
{
 public:
  std::vector< std::vector<Lit> > &initClauses;
  std::vector< std::vector<Lit > > &formula;
  std::vector<lbool> currentAssigns;
  std::vector<lbool> onBranchAssigns;
  std::vector<int> levelVar;
  std::vector< std::vector<Var> > stack;
  std::vector<int> markedComponents;
  int nVars;

  inline void assign(Lit p, int level)
  {
    assert(currentAssigns[var(p)] == l_Undef);
    currentAssigns[var(p)] = lbool(!sign(p));

    assert(level < (int) stack.size());
    stack[level].push_back(var(p));
    levelVar[var(p)] = level;
  }

  inline void assignOnBranch(Lit l){onBranchAssigns[var(l)] = lbool(!sign(l));}
  inline void unassignOnBranch(Lit l){onBranchAssigns[var(l)] = l_Undef;}
  inline lbool valueOnBranch(Lit l) {return onBranchAssigns[var(l)] ^ sign(l);}

  inline void printAssignOnBranch()
  {
    std::cout << "printAssignOnBranch: ";
    for(unsigned i = 1 ; i<onBranchAssigns.size() ; i++)
      if(onBranchAssigns[i] == l_Undef) std::cout << i << "(U) ";
      else if(onBranchAssigns[i] == l_False) std::cout << i << "(F) ";
      else std::cout << i << "(T) ";
    std::cout << "\n";
  }

  inline int getLevel(Var v){return levelVar[v];}
  inline int getLevel(Lit l){return levelVar[var(l)];}
  inline int stackLevel(){return stack.size() - 1;}
  inline void pushNewLevel(){stack.push_back(std::vector<Var>());}

  inline void printCurrentAssign()
  {
    for(unsigned i = 0 ; i<currentAssigns.size() ; i++)
    {
      if(currentAssigns[i] == l_Undef) continue;
      std::cout << (currentAssigns[i] == l_False ? "-" : "") << i << "(" << getLevel(i) << ")"<< " ";
    }
    std::cout << "\n";
  }

  inline void popUntil(int level)
  {
    while(stackLevel() > level)
    {
      std::vector<Var> &v = stack.back();
      for(unsigned i = 0 ; i<v.size() ; i++)
      {
        currentAssigns[v[i]] = l_Undef;
        levelVar[v[i]] = -1;
      }
      stack.pop_back();
    }
  }// popUntil

  inline lbool currentValue (Lit p) const { return currentAssigns[var(p)] ^ sign(p);}


  Problem(int nbVar, std::vector< std::vector<Lit> > &ic, std::vector< std::vector<Lit> > &f) :
      initClauses(ic),
      formula(f)
  {
    nVars = nbVar;

    for(int i = 0 ; i <= nbVar ; i++)
    {
      currentAssigns.push_back(l_Undef);
      onBranchAssigns.push_back(l_Undef);
      levelVar.push_back(-1); // warning, that means it is not defined because currentAssigns is undef
      markedComponents.push_back(0);
    }
    stack.push_back(std::vector<Var>()); // prepare the level zero
  }
};


class Branch
{
 public:
  std::vector<Lit> units;

  Branch(std::vector<Lit> &_units) : units(_units) {}

  void reduceSetOfIdxClauses(Problem &p, std::vector<int> &idxClause, std::vector<int> &result,
                             std::vector<int> &unkResult, std::vector<bool> varMarked)
  {
    for(unsigned i = 0 ; i<idxClause.size() ; i++)
    {
      int idx = idxClause[i];
      assert(idx < (int) p.initClauses.size());
      std::vector<Lit> &c = p.initClauses[idx];

      bool isSAT = false;
      bool withNotMarked = false;
      for(unsigned j = 0 ; !isSAT && j<c.size() ; j++)
      {
        isSAT = (p.valueOnBranch(c[j]) == l_True);
        if(!withNotMarked && p.valueOnBranch(c[j]) == l_Undef) withNotMarked = !varMarked[var(c[j])];
      }

      if(isSAT) continue;
      if(withNotMarked) unkResult.push_back(idx); else result.push_back(idx);
    }
  }// reduceSetOfIdxClauses
};


class Dag
{
 public:
  mpz_int saveCount;
  bool saveStatus;
  int type;
  int nbLinks;

  std::vector<int> cached;
  std::vector<bool> marked;

  std::vector<Var> formulaVarPresent;
  bool status;
  bool checked;
  int stamp;

  inline int globalStamp(bool inc = false)
  {
    static int gblStamp = 0;
    if(inc) gblStamp++;
    return gblStamp;
  }

  Dag()
  {
    checked = false;
    stamp = 0;
    type = TYPE_UNDEF;
    nbLinks = 0;
  }

  Dag(int t)
  {
    checked = false;
    stamp = 0;
    type = t;
    nbLinks = 0;
  }


  virtual bool checkStatusChecked(bool isRoot) = 0;
  virtual ~Dag(){ }
  virtual mpz_int computeNbModels(std::vector<bool> &variables,
                                  std::vector<lbool> &currentAssigns, bool isRoot) = 0;
  virtual bool isSatQuery(std::vector<lbool> &currentAssigns, bool isRoot) = 0;

  virtual void decorateVar(int nbVar, bool isRoot) = 0;
  virtual void decorateStatus(bool isRoot) = 0;
  virtual bool check_(std::vector<int> &idxClauses, Problem &p, bool fromCache, bool status,
                      std::vector<Lit> &shouldBeUnits) = 0;


  void decorate(int nbVar, bool isRoot)
  {
    decorateVar(nbVar, isRoot);
    decorateStatus(isRoot);
  }


  bool check(std::vector< std::vector<Lit > > &clauses, std::vector< std::vector<Lit > > &learnts, int nbVar)
  {
    Problem p(nbVar, clauses, learnts);
    while((int) marked.size() <= nbVar) marked.push_back(false);

    bool isInConflict = false;
    for(unsigned i = 0 ; !isInConflict && i<learnts.size() ; i++)
    {
      if(learnts[i].size() == 0) isInConflict = true;
      else if(learnts[i].size() == 1)
      {
        if(p.currentValue(learnts[i][0]) == l_False) isInConflict = true;
        if(p.currentValue(learnts[i][0]) == l_Undef) p.assign(learnts[i][0], 0);
      }
    }

    std::vector<int> idxClauses;
    for(unsigned i = 0 ; i<clauses.size() ; i++)
    {
      std::vector<Lit> &cl = clauses[i];

      bool isSAT = false;
      for(auto l : cl) if(p.currentValue(l) == l_True) {isSAT = true; break;}
      if (!isSAT) idxClauses.push_back(i);
    }

    std::vector<Lit> shouldBeUnits;
    bool ret = check_(idxClauses, p, false, true, shouldBeUnits);
    assert(!shouldBeUnits.size());
    assert(!p.stackLevel());
    return ret;
  }// check


  inline void getFormula(std::vector<int> &idxClause, Problem &p, std::vector< std::vector<int> > &clauses)
  {
    for(unsigned i = 0 ; i<idxClause.size() ; i++)
    {
      int idx = idxClause[i];
      assert(idx < (int) p.initClauses.size());
      std::vector<Lit> &c = p.initClauses[idx];

      bool isSAT = false;
      std::vector<int> tmpCl;
      for(unsigned j = 0 ; !isSAT && j<c.size() ; j++)
      {
        isSAT = (p.valueOnBranch(c[j]) == l_True);
        if(p.valueOnBranch(c[j]) == l_Undef) tmpCl.push_back(toInt(c[j]));
      }

      assert(!isSAT);
      assert(tmpCl.size() > 1);
      clauses.push_back(tmpCl);
    }
  }// getFormula


  inline bool sameClause(std::vector<int> &cl1, std::vector<int> &cl2)
  {
    bool same = cl1.size() == cl2.size();
    for(unsigned j = 0 ; same && j<cl1.size() ; j++) same = cl1[j] == cl2[j];
    return same;
  }// sameClause

  inline bool cacheConsistency(std::vector<int> &idxClauses, Problem &p)
  {
    std::vector< std::vector<int> > residualFormula;
    getFormula(idxClauses, p, residualFormula);

    // we sort
    std::vector<int> idxSorted;
    for(unsigned i = 0 ; i<residualFormula.size() ; i++)
    {
      std::sort(residualFormula[i].begin(), residualFormula[i].end());
      idxSorted.push_back(i);
    }
    sort(idxSorted.begin(), idxSorted.end(), sort_lt(residualFormula));

    // cache consistancy
    if(!cached.size()) // we create the cache entry if it does not exist
    {
      for(unsigned i = 0 ; i<idxSorted.size() ; i++)
      {
        std::vector<int> &cl = residualFormula[idxSorted[i]];
        if(i && sameClause(cl, residualFormula[idxSorted[i-1]])) continue;
        for(unsigned j = 0 ; j<cl.size() ; j++) cached.push_back(cl[j]);
        cached.push_back(0);
      }
      return true;
    }
    else // we compare with the cache entry
    {
      int idxCached = 0;
      for(unsigned i = 0 ; i<idxSorted.size() ; i++)
      {
        std::vector<int> &cl = residualFormula[idxSorted[i]];
        if(i && sameClause(cl, residualFormula[idxSorted[i-1]])) continue;

        for(unsigned j = 0 ; j<cl.size() ; j++)
        {
          assert(idxCached < (int) cached.size());
          if(idxCached >= (int) cached.size()) return false;

          assert(cl[j] == cached[idxCached]);
          if(cl[j] != cached[idxCached]) return false;
          idxCached++;
        }
        if(cached[idxCached] != 0)
        {
          assert(0);
          return false;
        }
        idxCached++;
      }
      return true;
    }
  }// cacheConsistency
};

class OrNode : public Dag
{
 public:
  std::vector<Branch *> branchs;
  std::vector<Dag *> nodes;
  std::vector<int> idxReason;
  std::vector<bool> fromCache;

  OrNode(std::vector<int> &idxR) : Dag(TYPE_OR), idxReason(idxR) {}

  ~OrNode()
  {
    assert(!nbLinks);

    for(unsigned i = 0 ; i<nodes.size() ; i++)
    {
      nodes[i]->nbLinks--;
      delete(branchs[i]);
      if(!nodes[i]->nbLinks) delete(nodes[i]);
    }
    nodes.clear();
    branchs.clear();
  }


  void decorateVar(int nbVar, bool isRoot)
  {
    assert(branchs.size() == nodes.size());
    int glbStamp = globalStamp(isRoot);
    if(stamp == glbStamp) return;
    stamp = glbStamp;

    assert(!formulaVarPresent.size());
    if(isRoot) for(int i = 1 ; i<=nbVar ; i++) formulaVarPresent.push_back(i);

    std::vector<bool> marked(nbVar+1, false);

    // compute
    for(unsigned i = 0 ; i<branchs.size() ; i++)
    {
      // transfer the units
      for(unsigned j = 0 ; !isRoot && j<branchs[i]->units.size() ; j++)
      {
        if(!marked[var(branchs[i]->units[j])])
        {
          marked[var(branchs[i]->units[j])] = true;
          formulaVarPresent.push_back(var(branchs[i]->units[j]));
        }
      }

      // propagate
      nodes[i]->decorateVar(nbVar, false);

      // union
      for(unsigned j = 0 ; !isRoot && j<nodes[i]->formulaVarPresent.size() ; j++)
      {
        Var v = nodes[i]->formulaVarPresent[j];
        if(!marked[v])
        {
          formulaVarPresent.push_back(v);
          marked[v] = true;
        }
      }
    }
  } // decorateVar


  void decorateStatus(bool isRoot)
  {
    int glbStamp = globalStamp(isRoot);
    if(stamp == glbStamp) return;
    stamp = glbStamp;

    status = false;
    for(unsigned i = 0 ; i<nodes.size(); i++)
    {
      nodes[i]->decorateStatus(false);
      status = status || nodes[i]->status;
    }
  }


  mpz_int computeNbModels(std::vector<bool> &variables, std::vector<lbool> &currentAssigns, bool isRoot)
  {
    int glbStamp = globalStamp(isRoot);
    if(stamp == glbStamp) return saveCount;
    stamp = glbStamp;

    saveCount = 0;
    for(unsigned i = 0 ; i<nodes.size() ; i++)
    {
      // check if the branch is SAT/UNSAT
      bool isUnsat = false;
      for(unsigned j = 0 ; !isUnsat && j<branchs[i]->units.size() ; j++)
        isUnsat = value(currentAssigns, branchs[i]->units[j]) == l_False;
      if(isUnsat) continue;

      // recursive call
      mpz_int tmp = nodes[i]->computeNbModels(variables, currentAssigns, false);

      // consider the free variables
      mpz_int freeModels = 1;
      for(unsigned j = 0 ; j<nodes[i]->formulaVarPresent.size() ; j++)
        variables[nodes[i]->formulaVarPresent[j]] = false;

      for(unsigned j = 0 ; j<branchs[i]->units.size() ; j++)
        variables[var(branchs[i]->units[j])] = false;

      for(unsigned j = 0 ; j<formulaVarPresent.size() ; j++)
      {
        if(!variables[formulaVarPresent[j]]) variables[formulaVarPresent[j]] = true;
        else if(!isAssigned(currentAssigns, formulaVarPresent[j])) freeModels *= 2;
      }

      // sum
      saveCount += tmp * freeModels;
    }

    return saveCount;
  } // computeNbModels


  bool isSatQuery(std::vector<lbool> &currentAssigns, bool isRoot)
  {
    int glbStamp = globalStamp(isRoot);
    if(stamp == glbStamp) return saveStatus;
    stamp = glbStamp;

    saveStatus = false;
    for(unsigned i = 0 ; !saveStatus && i<nodes.size() ; i++)
    {
      // check if the branch is SAT/UNSAT
      bool isUnsat = false;
      for(unsigned j = 0 ; !isUnsat && j<branchs[i]->units.size() ; j++)
        isUnsat = value(currentAssigns, branchs[i]->units[j]) == l_False;
      if(isUnsat) continue;

      // recursive call
      saveStatus = nodes[i]->isSatQuery(currentAssigns, false);
    }

    return saveStatus;
  } // isSatQuery



  void addBranch(Dag *d, std::vector<Lit> &units, bool fcache)
  {
    d->nbLinks++;
    nodes.push_back(d);
    branchs.push_back(new Branch(units));
    fromCache.push_back(fcache);
  } // addBranch


  /**
     Test if the unit literal given by the current branch are well
     propagated using the set of clauses associated with.
  */
  bool testUnitLiteral(Branch *b, Problem &p, bool dec, std::vector<Lit> &shouldBeUnits)
  {
    if(dec)
    {
      if(p.currentValue(b->units[0]) == l_False) return false;
      if(p.currentValue(b->units[0]) == l_Undef) p.assign(b->units[0], p.stackLevel());
    }

    // collect the set of variables that should be unit somewhere in another component
    for(auto v : formulaVarPresent) p.markedComponents[v] = true;
    for(unsigned i = 0 ; i<idxReason.size() ; i++)
    {
      std::vector<Lit> &cl = p.formula[idxReason[i]];
      for(auto l : cl)
      {
        if(p.currentValue(l) != l_Undef) continue;
        if(p.markedComponents[var(l)]) continue;

        // l should be assigned and then propagated before.
        Lit tl = lit_Undef;
        for(auto m : shouldBeUnits) if(var(m) == var(l)){ tl = m; break;}
        assert(tl != ~l);
        if(tl == ~l) exit(3);

        if(tl == lit_Undef) shouldBeUnits.push_back(l);
      }
    }


    // perform unit propagation on a subset of clauses
    bool fixPoint = false;
    while(!fixPoint)
    {
      fixPoint = true;

      for(unsigned i = 0 ; i<idxReason.size() ; i++)
      {
        assert(idxReason[i] >= 0);
        assert(idxReason[i] < (int) p.formula.size());

        std::vector<Lit> &cl = p.formula[idxReason[i]];
        int level = 0;
        Lit l = lit_Undef;

        unsigned j = 0;
        for( ; j<cl.size() ; j++)
        {
          if(p.currentValue(cl[j]) == l_True) break;
          if(p.currentValue(cl[j]) == l_Undef)
          {
            if(!p.markedComponents[var(cl[j])]) continue;
            if(l != lit_Undef) break;
            l = cl[j];
          }else if (p.getLevel(cl[j]) > level) level = p.getLevel(cl[j]);
        }

        if(j<cl.size() || l == lit_Undef) continue;
        p.assign(l, level);
        fixPoint = false;
      }
    }

    // reinit the vector used to mark the variable in the current component
    for(auto v : formulaVarPresent) p.markedComponents[v] = false;
    
    for(auto l : b->units)
    {
      assert(p.currentValue(l) != l_Undef);
      if(p.currentValue(l) != l_True) return false;
    }

    return true;
  }// testUnitLiteral


  /**
     Test if a branch is correct.
  */
  bool testBranch(std::vector<int> &idxClauses, Problem &p, Branch *b, Dag *n, bool dec,
                  bool fcache, bool fatherStatus, std::vector<Lit> &shouldBeUnits)
  {
    // we prepare the interpretation
    if(dec) p.pushNewLevel();
    std::vector<Lit> &units = b->units;
    for(unsigned i = 0 ; i<units.size() ; i++) p.assignOnBranch(units[i]);

    bool ret = false;
    if(!testUnitLiteral(b, p, dec, shouldBeUnits))
      ret = !n->status || n->isSatQuery(p.onBranchAssigns, true); // UNS case
    else
    {
      // we reduce the set of clauses regarding the information contained in the branch
      static std::vector<bool> varMarked;
      for(auto v : n->formulaVarPresent)
      {
        while(v >= (int) varMarked.size()) varMarked.push_back(false);
        varMarked[v] = true;
      }

      std::vector<int> idxUnknown, lSubIdxClauses;
      b->reduceSetOfIdxClauses(p, idxClauses, lSubIdxClauses, idxUnknown, varMarked);
      for(auto v : n->formulaVarPresent) varMarked[v] = false;

      for(auto idx : idxUnknown)
      {
        std::vector<Lit> assums;
        std::vector<Lit> &c = p.initClauses[idx];

        for(unsigned j = 0 ; j<c.size() ; j++) if(p.valueOnBranch(c[j]) == l_Undef) assums.push_back(~c[j]);

        for(auto l : assums) p.assignOnBranch(l);
        bool isImplied = n->isSatQuery(p.onBranchAssigns, true);
        for(auto l : assums) p.unassignOnBranch(l);

        assert(!isImplied);
        if(isImplied) return false;
      }

      // check the branch itself
      ret = n->check_(lSubIdxClauses, p, fcache, fatherStatus && status, shouldBeUnits);
    }

    // restore the current trail (unit from the root to the current node)
    if(dec) p.popUntil(p.stackLevel() - 1);
    for(unsigned i = 0 ; i<b->units.size() ; i++) p.unassignOnBranch(b->units[i]);

    assert(ret);
    return ret;
  }// testBranch


  bool checkStatusChecked(bool isRoot)
  {
    int glbStamp = globalStamp(isRoot);
    if(stamp == glbStamp) return true;
    stamp = glbStamp;

    assert(checked);
    for(unsigned i = 0 ; i<nodes.size() ; i++)
    {
      bool res = nodes[i]->checkStatusChecked(false);
      assert(res);
      if(!res) return res;
    }

    return checked;
  }

  /**
     Check out if the OrNode is correct (unit and caching).
  */
  bool check_(std::vector<int> &idxClauses, Problem &p, bool fcache, bool fatherStatus,
              std::vector<Lit> &shouldBeUnits)
  {
    bool cacheCheck = (nbLinks <= 1) || cacheConsistency(idxClauses, p);
    assert(cacheCheck);
    if(fcache) return cacheCheck;

    // we cannot check out a cache entry if the path from the root to this node
    // contains a insatisfiable node
    assert(nbLinks <= 1 || fatherStatus);
    if(nbLinks > 1 && !fatherStatus) return false;

    checked = true;
    assert(nodes.size() == 1 || nodes.size() == 2);
    if(nodes.size() == 1)
    {
      bool ret = testBranch(idxClauses, p, branchs[0], nodes[0], false, fromCache[0],
                            fatherStatus && status, shouldBeUnits);
      assert(ret);
      return ret;
    }
    else
    {
      //!\\ here we only consider decision node!
      assert(nodes.size() == 2);
      assert(!(!branchs[0]->units.size() || !branchs[1]->units.size()
               || branchs[0]->units[0] != ~branchs[1]->units[0]));
      if(!branchs[0]->units.size() || !branchs[1]->units.size()
         || branchs[0]->units[0] != ~branchs[1]->units[0]) return false;

      bool ret = testBranch(idxClauses, p, branchs[0], nodes[0], true, fromCache[0],
                            fatherStatus && status, shouldBeUnits);
      assert(ret);
      if(!ret) return false;

      ret = testBranch(idxClauses, p, branchs[1], nodes[1], true, fromCache[1],
                       fatherStatus && status, shouldBeUnits);
      assert(ret);
      return ret;
    }
  } // check_
};


class AndNode : public Dag
{
 public:
  std::vector<Dag *> nodes;
  std::vector<int> idxReason;
  std::vector<bool> fromCache;

  AndNode(std::vector<int> &idxR) : Dag(TYPE_AND), idxReason(idxR){}

  ~AndNode()
  {
    assert(!nbLinks);

    for(unsigned i = 0 ; i<nodes.size() ; i++)
    {
      nodes[i]->nbLinks--;
      if(!nodes[i]->nbLinks) delete(nodes[i]);
    }
  }


  void decorateVar(int nbVar, bool isRoot)
  {
    int glbStamp = globalStamp(isRoot);
    assert(stamp != glbStamp); // we cannot go through twice the same nodes
    stamp = glbStamp;

    assert(!formulaVarPresent.size());
    if(isRoot) for(int i = 1 ; i<=nbVar ; i++) formulaVarPresent.push_back(i);

    std::vector<bool> marked(nbVar+1, false);

    // compute
    for(unsigned i = 0 ; i<nodes.size() ; i++)
    {
      // get the information if needed
      if(nodes[i]->stamp != glbStamp) nodes[i]->decorateVar(nbVar, false);

      // collect
      for(unsigned j = 0 ; !isRoot && j<nodes[i]->formulaVarPresent.size() ; j++)
      {
        Var v = nodes[i]->formulaVarPresent[j];
        if(!marked[v])
        {
          formulaVarPresent.push_back(v);
          marked[v] = true;
        }
      }
    }
  } // decorateVar


  void decorateStatus(bool isRoot)
  {
    int glbStamp = globalStamp(isRoot);
    if(stamp == glbStamp) return;
    stamp = glbStamp;

    status = true;
    for(unsigned i = 0 ; i<nodes.size(); i++)
    {
      nodes[i]->decorateStatus(false);
      status = status && nodes[i]->status;
    }
  }


  mpz_int computeNbModels(std::vector<bool> &variables, std::vector<lbool> &currentAssigns, bool isRoot)
  {
    int glbStamp = globalStamp(isRoot);
    if(stamp == glbStamp) return saveCount;
    stamp = glbStamp;

    saveCount = 1;
    for(unsigned i = 0 ; i<nodes.size() ; i++)
    {
      // recursive call
      mpz_int tmp = nodes[i]->computeNbModels(variables, currentAssigns, false);
      if(tmp == 0) return saveCount = 0;

      // consider the free variables
      for(unsigned j = 0 ; j<nodes[i]->formulaVarPresent.size() ; j++)
        variables[nodes[i]->formulaVarPresent[j]] = false;

      // sum
      saveCount *= tmp;
    }

    mpz_int freeModels = 1;
    for(unsigned j = 0 ; j<formulaVarPresent.size() ; j++)
      if(!variables[formulaVarPresent[j]]) variables[formulaVarPresent[j]] = true;
      else if(!isAssigned(currentAssigns, formulaVarPresent[j])) freeModels *= 2;

    assert(freeModels == 1);
    saveCount *= freeModels;
    return saveCount;
  } // computeNbModels


  bool isSatQuery(std::vector<lbool> &currentAssigns, bool isRoot)
  {
    int glbStamp = globalStamp(isRoot);
    if(stamp == glbStamp) return saveStatus;
    stamp = glbStamp;

    saveStatus = true;
    for(unsigned i = 0 ; saveStatus && i<nodes.size() ; i++)
      saveStatus = nodes[i]->isSatQuery(currentAssigns, false);

    return saveStatus;
  } // isSatQuery

  void addBranch(Dag *d, bool fcache)
  {
    assert(d->type != TYPE_FALSE);
    d->nbLinks++;
    nodes.push_back(d);
    fromCache.push_back(fcache);
  }

  bool checkStatusChecked(bool isRoot)
  {
    int glbStamp = globalStamp(isRoot);
    if(stamp == glbStamp) return true;
    stamp = glbStamp;


    assert(checked);
    for(unsigned i = 0 ; i<nodes.size() ; i++)
    {
      bool res = nodes[i]->checkStatusChecked(false);
      assert(res);
      if(!res) return res;
    }

    return checked;
  }

  bool check_(std::vector<int> &idxClauses, Problem &p, bool fcache, bool fatherStatus,
              std::vector<Lit> &shouldBeUnits)
  {
    bool cacheCheck = cacheConsistency(idxClauses, p);
    assert(cacheCheck);
    if(fcache) return cacheCheck;

    // we cannot check out a cache entry if the path from the root to this node
    // contains a insatisfiable node
    assert(nbLinks <= 1 || fatherStatus);
    if(nbLinks > 1 && !fatherStatus) return false;

    bool nextStatus = status && fatherStatus;
    checked = true;

    // ranked the variables w.r.t. their component
    std::vector<int> idxComponent(p.nVars + 1, -1);

    for(unsigned i = 0 ; i<nodes.size() ; i++)
    {
      std::vector<Var> &vars = nodes[i]->formulaVarPresent;
      for(auto v : vars)
      {
        assert(idxComponent[v] == -1);
        if(idxComponent[v] != -1) return false; // empty intersection checked here
        idxComponent[v] = i;
      }
    }

    // distribute the clauses
    std::vector<std::vector<int>> idxDistribution(nodes.size(), std::vector<int>());
    std::vector<int> unknownPlace;

    for(auto idx : idxClauses)
    {
      std::vector<Lit> &c = p.initClauses[idx];

      int pos = -1;
      bool isUnknown = false;
      for(unsigned j = 0 ; !isUnknown && j<c.size() ; j++)
      {
        // normally the SAT clauses are already removed by
        // Branch::reduceSetOfIdxClauses
        assert(p.valueOnBranch(c[j]) != l_True);
        if(p.valueOnBranch(c[j]) == l_False) continue;

        Var v = var(c[j]);
        if(idxComponent[v] == -1) isUnknown = true;                    // free variable
        else if(pos != -1 && idxComponent[v] != pos) isUnknown = true; // share between two components
        else if(pos == -1) pos = idxComponent[v];
      }

      if(isUnknown) unknownPlace.push_back(idx);
      else idxDistribution[pos].push_back(idx);
    }

    // check out the clauses that are not fully belonging to a component
    for(auto idx : unknownPlace)
    {
      std::vector<Lit> assums;
      std::vector<Lit> &c = p.initClauses[idx];
      for(unsigned j = 0 ; j<c.size() ; j++)
        if(p.valueOnBranch(c[j]) == l_Undef) assums.push_back(~c[j]);

      for(auto l : assums) p.assignOnBranch(l);
      bool isImplied = false;

      for(auto n : nodes)
      {
        isImplied = !n->isSatQuery(p.onBranchAssigns, true);
        if(isImplied) break;
      }

      for(auto l : assums) p.unassignOnBranch(l);
      assert(isImplied);
      if(!isImplied) return false;
    }


    // call recursively on all components
    bool ret = true;
    for(unsigned i = 0 ; ret && i<nodes.size() ; i++)
      ret = nodes[i]->check_(idxDistribution[i], p, fromCache[i], nextStatus, shouldBeUnits);
    assert(ret);


    // consider the literal that should be unit.
    unsigned i, j;
    for(i = j = 0 ; i<shouldBeUnits.size() ; i++)
    {
      int idx = idxComponent[var(shouldBeUnits[i])];
      if(idx == -1) shouldBeUnits[j++] = shouldBeUnits[i]; // postpone
      else
      {
        p.assignOnBranch(~shouldBeUnits[i]);
        bool isImplied = nodes[idx]->isSatQuery(p.onBranchAssigns, true);
        p.unassignOnBranch(~shouldBeUnits[i]);

        assert(isImplied);
        if(!isImplied) return false;
      }
    }
    shouldBeUnits.resize(j);

    return ret;
  }
};

class False : public Dag
{
 public:
  False(){status = false; type = TYPE_FALSE;}
  ~False(){assert(!nbLinks);}
  inline bool check_(std::vector<int> &idxClauses, Problem &p, bool fcache, bool fatherStatus,
                     std::vector<Lit> &shouldBeUnits)
  {
    return true;
  }

  void decorateVar(int nbVar, bool isRoot) {}
  void decorateStatus(bool isRoot) {status = false;}
  mpz_int computeNbModels(std::vector<bool> &variables, std::vector<lbool> &currentAssigns, bool isRoot)
  {
    return 0;
  }

  bool checkStatusChecked(bool isRoot) {return true;}
  bool isSatQuery(std::vector<lbool> &currentAssigns, bool isRoot){return false;}
};


class True : public Dag
{
 public:
  True() : Dag(){status = true; type = TYPE_TRUE;}
  ~True(){assert(!nbLinks);}
  inline bool check_(std::vector<int> &idxClauses, Problem &p, bool fcache, bool fatherStatus,
                     std::vector<Lit> &shouldBeUnits)
  {
    for(unsigned i = 0 ; i<idxClauses.size() ; i++)
    {
      bool isSAT = false;
      std::vector<Lit> &c = p.initClauses[idxClauses[i]];
      for(unsigned j = 0 ; !isSAT && j<c.size() ; j++) isSAT = p.currentValue(c[j]) == l_True;
      assert(isSAT);
      if(!isSAT) return false;
    }

    return true;
  } // check_

  bool checkStatusChecked(bool isRoot) {return true;}
  void decorateVar(int nbVar, bool isRoot) {}
  void decorateStatus(bool isRoot) {status = true;}
  mpz_int computeNbModels(std::vector<bool> &variables, std::vector<lbool> &currentAssigns, bool isRoot)
  {
    return 1;
  }

  bool isSatQuery(std::vector<lbool> &currentAssigns, bool isRoot){return true;}
};

};
#endif
