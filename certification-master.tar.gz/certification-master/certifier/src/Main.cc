#include <iostream>
#include <errno.h>
#include <vector>

#include <signal.h>
#include <zlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>

#include "SolverTypes.hh"
#include "Parser.hh"
#include "Dag.hh"

#include <boost/multiprecision/gmp.hpp>
using namespace boost::multiprecision;


inline double cpuTime()
{
  struct rusage ru;
  getrusage(RUSAGE_SELF, &ru);
  return (double)ru.ru_utime.tv_sec + (double)ru.ru_utime.tv_usec / 1000000;
}


void printClauses(std::vector< std::vector<Certifier::Lit> > &clauses)
{
  for(auto cl : clauses)
  {
    for(auto l : cl) std::cout << ((sign(l)) ? "-" : "") << var(l) << " ";
    std::cout << "0\n";
  }
}


int main(int argc, char** argv)
{
  if(argc <= 1)
    {
      printf("USAGE: ./certificator <input-file> <input-dDnnf> <input-drat>\n");
      exit(42);
    }

  assert(argc >= 4);
  double initial_time = cpuTime();

  // get the CNF formula
  std::vector< std::vector<Certifier::Lit> > clauses;
  int nbVarCNF = Certifier::parse_DIMACS(argv[1], clauses);

  printf("c CNF information\n");
  printf("c Number of variables: %d\n", nbVarCNF);
  printf("c Number of clauses: %lu\n", clauses.size());

  // get the added clause from the DRAT file + check if the clause can be derived
  std::vector< std::vector<Certifier::Lit> > usedClauses;
  Certifier::parse_DRAT(argv[3], usedClauses);
  printf("c\nc DRAT information\n");
  printf("c Number of drat clauses: %lu\n", usedClauses.size());

  // parse the dDNNF formula
  double allTimeCheckDnnf = cpuTime(), timeCheckDdnnf = allTimeCheckDnnf;
  printf("c\n");
  Certifier::Dag *d = Certifier::parse_DDnnf(argv[2]);
  d->decorate(nbVarCNF, true);

  printf("c DDnnf parsing: %.3lf\n", cpuTime() - timeCheckDdnnf);
  timeCheckDdnnf = cpuTime();

  int retStatus = 0;
  if(d->check(clauses, usedClauses, nbVarCNF) && d->checkStatusChecked(true))
    printf("c DDnnf checked: %.3lf\n", cpuTime() - allTimeCheckDnnf);
  else
    {
      printf("c DDnnf unchecked\n");
      retStatus = 3;
    }
  delete(d);

  printf("c\n");
  printf("c Global time: %.3f\n", cpuTime() - initial_time);

  exit(retStatus);
}
